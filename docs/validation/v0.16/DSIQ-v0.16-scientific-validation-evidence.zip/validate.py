"""Re-score supplied archives, then run new deterministic circuits. No known reference values are passed to engines."""
import sys, pathlib, json, hashlib, math, random, time, platform, os, decimal, resource
import numpy as np
import mpmath as mp
from decimal import Decimal as D
ROOT=pathlib.Path(sys.argv[1]).resolve(); E=pathlib.Path(sys.argv[2]).resolve(); OUT=pathlib.Path(sys.argv[3]).resolve();sys.path.insert(0,str(ROOT/'native'))
import query_contraction as qc, integer_query_contraction as iq, quad_query as qq
mp.mp.dps=85;decimal.getcontext().prec=105

def load(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(o):return hashlib.sha256((json.dumps(o,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()).hexdigest()
def write(name,x): (OUT/name).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
manifest=load(E/'scientific-source-manifest.json'); checks={p:sha(ROOT/p)==h for p,h in manifest['files'].items()}; actual=digest({p:sha(ROOT/p) for p in checks});assert all(checks.values()) and actual==manifest['sourceSHA256']; integrity=load(E/'integrity-summary.json'); audit={'sourceFiles':len(checks),'sourceMatches':sum(checks.values()),'sourceSHA256':actual,'sourceZipMatches':sha(pathlib.Path('/mnt/data/DSIQ-v0.16-private-engineering-candidate(1).zip'))==integrity['sourceZipSHA256'],'campaigns':{}}
rows=[]
for suite in ['medium','high','opus']:
 p=E/'raw'/suite; mf=p/('manifest.json' if suite=='opus' else 'output-manifest.json'); man=load(mf); chpath=E/'inputs'/suite/'challenge.json'; ch=load(chpath); commitment=E/'inputs'/suite/'commitment.json'; assert sha(chpath)==man['challengeSHA256']==load(commitment)['challengeSHA256']; assert sha(mf)==integrity['campaignManifestSHA256'][suite]
 if suite!='opus':
  assert sha(commitment)==man['commitmentSHA256']; sm=load(p/'source-manifest.json'); assert sm==manifest and man['sourceSHA256']==actual and man['sourceUnchanged']
 refs=({'medium':lambda:{c['id']:{q['id']:(q['refReal'],q['refImag']) for q in c['queries']} for c in load(E/'references/medium/recomputed-score.json')['cases']},'high':lambda:load(E/'references/high/precision.json'),'opus':lambda:load(E/'references/opus/reveal-private.json')['reference']['circuits']})[suite]()
 count=passed=strict=enclosed=relcert=checkpoints=expected=0; per=[]
 for c in ch['circuits']:
  cid=c['id']; req=c['request']; raw=p/(cid+'.json'); a=load(raw); assert sha(raw)==(man['files'][cid] if suite=='opus' else man['circuits'][cid]['sha256']); assert a['inputSHA256']==digest(req)
  w=a if suite=='opus' else a['workerReport']; outputs=w['records'] if suite=='opus' else w['outputs']; assert len(outputs)==len(req['queries']); qmap={q['id']:q for q in outputs}; assert len(qmap)==len(outputs)
  cps=[] if suite=='opus' else [e for e in w['events'] if e['kind']=='checkpoint']; wanted=sorted({0,len(req['gates']),*(q['prefix'] for q in req['queries']),*range(req['checkpointEvery'],len(req['gates']),req['checkpointEvery'])}); checkpoints+=len(cps);expected+=len(wanted)
  assert suite=='opus' or [e['prefix'] for e in cps]==wanted
  for q in req['queries']:
   v=qmap[q['id']]; assert v['kind']==q['kind'] and v['prefix']==q['prefix']; val=v['value']; ref=refs[cid][q['id']]; rr,ri=(D(ref['real']),D(ref['imag'])) if suite=='opus' else (D(ref[0]),D(ref[1])); re,im=D(val['real']),D(val.get('imag',0)); err=((re-rr)**2+(im-ri)**2).sqrt(); mag=(rr*rr+ri*ri).sqrt(); rel=err/mag if q['kind']=='amplitude' and mag else None; ok=err<=D('1e-13') and (rel is None or rel<=D('1e-9')); b=val.get('absoluteErrorBound'); bound=b is not None and D(b)>=err; strict+=req['requireCertificate']; enclosed+=bool(req['requireCertificate'] and bound); relcert+=bool(req['requireCertificate'] and rel is not None and val.get('relativeErrorUpperBound') is not None and val['relativeErrorUpperBound']<=1e-9);count+=1;passed+=ok
   rows.append({'suite':suite,'case':cid,'n':req['n'],'kind':q['kind'],'id':q['id'],'absoluteError':float(err),'relativeError':float(rel) if rel is not None else None,'strict':req['requireCertificate'],'encloses':bound,'pass':ok})
  per.append({'case':cid,'n':req['n'],'gates':len(req['gates']),'elapsedSeconds':a['elapsedSeconds'],'peakRssMiB':a['childPeakRssKiB']/1024,'queryCount':len(outputs),'checkpoints':len(cps)})
 audit['campaigns'][suite]={'caseFilesVerified':len(per),'queries':count,'passed':passed,'strict':strict,'enclosed':enclosed,'relativeToleranceCertified':relcert,'checkpoints':checkpoints,'expectedCheckpoints':expected,'manifestHash':sha(mf),'elapsedSeconds':man['elapsedSeconds'],'maxAbsoluteError':max(r['absoluteError'] for r in rows if r['suite']==suite),'maxRelativeError':max(r['relativeError'] for r in rows if r['suite']==suite and r['relativeError'] is not None),'cases':per}
write('archive-audit.json',audit);write('rescore-queries.json',rows)
print('ARCHIVE AUDIT', {s:{k:v for k,v in a.items() if k!='cases'} for s,a in audit['campaigns'].items()},flush=True)
# New seeded workloads. Dense reference: independently implemented 85-decimal two-state updates.
seed=202611190753;rng=random.Random(seed); fresh=[]; inputs=[]
def gate(name,q,controls=None,theta=None):
 g={'name':name,'q':q,'controls':controls or []};
 if theta is not None:g['theta']=theta
 return g
def mat(g):
 name=g['name']; t=mp.mpf(g.get('theta',0))/2;c=mp.cos(t);s=mp.sin(t);j=mp.j
 if name in ('x','cx'):return (0,1,1,0)
 if name in ('z','cz'):return (1,0,0,-1)
 if name=='h':v=1/mp.sqrt(2);return(v,v,v,-v)
 if name in ('rx','crx'):return(c,-j*s,-j*s,c)
 if name in ('ry','cry'):return(c,-s,s,c)
 if name in ('rz','crz'):return(mp.exp(-j*t),0,0,mp.exp(j*t))
 if name=='cp':return(1,0,0,mp.exp(j*2*t))
 raise ValueError(name)
def evolve(n,gs):
 a=[mp.mpc(1)]+[mp.mpc(0)]*((1<<n)-1)
 for g in gs:
  k=1<<g['q']; m=mat(g)
  for x in range(1<<n):
   if x&k or any(not x&(1<<q) for q in g['controls']):continue
   u,v=a[x],a[x|k];a[x]=m[0]*u+m[1]*v;a[x|k]=m[2]*u+m[3]*v
 return a
def compare(case,n,gs,targets,do_quad=True):
 start=time.monotonic(); ms=iq.matrices(gs) if do_quad else None
 for bits,ref in targets:
  for backend in (['fp64','binary128'] if do_quad else ['fp64']):
   q={'kind':'amplitude','bits':bits};b=qc.Budget(2**28,10**9,1000000);t=time.monotonic()
   try:
    if backend=='fp64':val,stats=qc.evaluate(n,gs,q,b);z=mp.mpc(float(val.real),float(val.imag));bound=None;rb=None
    else:val,stats=qq.evaluate(n,gs,q,b,ms);z=mp.mpc(val['real'],val['imag']);bound=val['absoluteErrorBound'];rb=val['relativeErrorUpperBound']
    err=abs(z-ref);rel=err/abs(ref) if ref else None;bounds=(bound is None or err<=mp.mpf(bound)+mp.mpf('1e-78')) and (rb is None or rel is None or rel<=mp.mpf(rb)+mp.mpf('1e-76'));ok=err<=mp.mpf('1e-13') and (rel is None or rel<=mp.mpf('1e-9')) and bounds
    fresh.append({'case':case,'n':n,'bits':bits,'backend':backend,'absoluteError':float(err),'relativeError':float(rel) if rel is not None else None,'absoluteBound':bound,'relativeBound':rb,'passed':bool(ok),'elapsedSeconds':time.monotonic()-t,'refReal':str(ref.real),'refImag':str(ref.imag),'real':float(z.real),'imag':float(z.imag)})
   except Exception as e:fresh.append({'case':case,'n':n,'bits':bits,'backend':backend,'passed':False,'error':str(e),'elapsedSeconds':time.monotonic()-t})
  write('fresh-queries.json',fresh)
 inputs.append({'case':case,'n':n,'gates':gs,'bits':[k for k,_ in targets]});write('fresh-inputs.json',inputs); print(case,n,len(targets),'elapsed',time.monotonic()-start,flush=True)
for case,n in enumerate([3,4,5,6,7,8]):
 gs=[]
 for layer in range(3):
  for q in range(n):gs.append(gate(rng.choice(['rx','ry','rz']),q,theta=rng.uniform(-2.9,2.9)))
  for j in range(n//2):
   a,b=rng.sample(range(n),2);name=rng.choice(['cx','cz','crx','cry','cp']);gs.append(gate(name,a,[b],rng.uniform(-2.5,2.5) if name not in ('cx','cz') else None))
 st=evolve(n,gs);xs=list(range(1<<n)) if n<=4 else rng.sample(range(1<<n),8);compare('dense-'+str(n),n,gs,[(format(x,f'0{n}b'),st[x]) for x in xs],True)
# Nonlocal disjoint entangled pairs, independently evaluated two-qubit blocks. Not a generic chaotic workload.
for n in (50,100):
 wires=list(range(n));rng.shuffle(wires);gs=[];blocks=[]
 for a,b in zip(wires[::2],wires[1::2]):
  th,ph,la=[rng.uniform(.2,2.7) for _ in range(3)];local=[gate('ry',0,theta=th),gate('cx',1,[0]),gate('rz',1,theta=ph),gate('rx',0,theta=la)];blocks.append((a,b,evolve(2,local)))
  for g in local:gs.append({**g,'q':[a,b][g['q']],'controls':[[a,b][q] for q in g['controls']]})
 targets=[]
 for _ in range(4):
  x=rng.getrandbits(n);r=mp.mpc(1)
  for a,b,st in blocks:r*=st[((x>>a)&1)+2*((x>>b)&1)]
  targets.append((format(x,f'0{n}b'),r))
 compare('pair-product-'+str(n),n,gs,targets,False)
summary={'seed':seed,'oracle':'85 decimal digits, independently coded pairwise dense evolution; products of 2-qubit blocks for 50 and 100','circuits':len(inputs),'rows':len(fresh),'pass':sum(x['passed'] for x in fresh),'maxRssKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'environment':{'python':platform.python_version(),'platform':platform.platform(),'numpy':np.__version__,'mpmath':mp.__version__},'sourceSHA256':actual,'byBackend':{}}
for backend in ['fp64','binary128']:
 rr=[r for r in fresh if r['backend']==backend];summary['byBackend'][backend]={'count':len(rr),'pass':sum(r['passed'] for r in rr),'maxAbsoluteError':max(r.get('absoluteError',0) for r in rr),'maxRelativeError':max(r.get('relativeError') or 0 for r in rr)}
write('fresh-summary.json',summary);print(json.dumps(summary,indent=2),flush=True)
