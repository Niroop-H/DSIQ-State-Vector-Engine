"""Score rerun manifests after execution, using original supplied references."""
import pathlib,sys,json,decimal,hashlib,collections,csv,re
from decimal import Decimal as D
decimal.getcontext().prec=105
E=pathlib.Path(sys.argv[1]);F=pathlib.Path(sys.argv[2]);load=lambda p:json.loads(p.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();digest=lambda obj:hashlib.sha256((json.dumps(obj,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()).hexdigest()
source=load(E/'scientific-source-manifest.json');stats={};rows=[];cases=[]
for suite in ['medium','high','opus']:
 p=F/(suite+'-rerun');mf=p/('manifest.json' if suite=='opus' else 'output-manifest.json');ch=load(E/'inputs'/suite/'challenge.json');commit=load(E/'inputs'/suite/'commitment.json');manifest=load(mf) if mf.exists() else None
 if manifest:
  assert manifest['challengeSHA256']==sha(E/'inputs'/suite/'challenge.json')==commit['challengeSHA256']
  if suite!='opus':assert manifest['commitmentSHA256']==sha(E/'inputs'/suite/'commitment.json') and manifest['sourceSHA256']==source['sourceSHA256'] and manifest['sourceUnchanged'] and load(p/'source-manifest.json')==source
 refs=({'medium':lambda:{c['id']:{q['id']:(q['refReal'],q['refImag']) for q in c['queries']} for c in load(E/'references/medium/recomputed-score.json')['cases']},'high':lambda:load(E/'references/high/precision.json'),'opus':lambda:load(E/'references/opus/reveal-private.json')['reference']['circuits']})[suite]()
 for c in ch['circuits']:
  cid=c['id'];req=c['request'];f=p/(cid+'.json');wanted=sorted({0,len(req['gates']),*(q['prefix'] for q in req['queries']),*range(req['checkpointEvery'],len(req['gates']),req['checkpointEvery'])});case={'suite':suite,'id':cid,'n':req['n'],'gates':len(req['gates']),'requested':len(req['queries']),'expectedCheckpoints':len(wanted),'status':'NOT_RUN','passed':0,'checkpoints':0};cases.append(case)
  if not f.exists():continue
  a=load(f);assert a['inputSHA256']==digest(req)
  if manifest:assert sha(f)==(manifest['files'][cid] if suite=='opus' else manifest['circuits'][cid]['sha256'])
  w=a if suite=='opus' else a.get('workerReport') or {};outs=w.get('records' if suite=='opus' else 'outputs',[]);qmap={q['id']:q for q in outs if 'value' in q};cps=[] if suite=='opus' else [x for x in w.get('events',[]) if x['kind']=='checkpoint'];case.update(status=a['status'],elapsedSeconds=a.get('elapsedSeconds'),peakRssMiB=a['childPeakRssKiB']/1024 if a.get('childPeakRssKiB') is not None else None,checkpoints=len(cps),checkpointComplete=[x['prefix'] for x in cps]==wanted,checkpointNormEnclosures=sum(D(x['norm'].get('absoluteErrorBound',-1))>=abs(D(x['norm']['real'])-1) for x in cps),exitCode=a.get('workerExitCode'),rawSHA256=sha(f))
  for q in req['queries']:
   row={'suite':suite,'case':cid,'n':req['n'],'id':q['id'],'kind':q['kind'],'strict':req['requireCertificate'],'pass':False,'returned':False};rows.append(row)
   if q['id'] not in qmap:continue
   v=qmap[q['id']];assert v['kind']==q['kind'] and v['prefix']==q['prefix'];val=v['value'];ref=refs[cid][q['id']];rr,ri=(D(ref['real']),D(ref['imag'])) if suite=='opus' else (D(ref[0]),D(ref[1]));re0,im0=D(val['real']),D(val.get('imag',0));err=((re0-rr)**2+(im0-ri)**2).sqrt();mag=(rr*rr+ri*ri).sqrt();rel=err/mag if q['kind']=='amplitude' and mag else None;ok=err<=D('1e-13') and (rel is None or rel<=D('1e-9'));b=val.get('absoluteErrorBound');bounds=b is not None and D(b)>=err;rb=val.get('relativeErrorUpperBound');row.update(returned=True,absoluteError=float(err),relativeError=float(rel) if rel is not None else None,**{'pass':ok},encloses=bounds,absTolCertificate=b is not None and b<=1e-13,relTolCertificate=rb is not None and rb<=1e-9);case['passed']+=ok
  case['queryComplete']=case['passed']==case['requested'] and a['status']==('QUERIES_COMPLETED' if suite=='opus' else 'COMPLETED')
 cs=[c for c in cases if c['suite']==suite];r=[q for q in rows if q['suite']==suite];st=[q for q in r if q['strict']];s={'manifestComplete':bool(manifest),'casesTotal':len(cs),'queryCompleteCases':sum(c.get('queryComplete',False) for c in cs),'queriesRequested':sum(c['requested'] for c in cs),'queriesReturned':sum(q['returned'] for q in r),'queriesPassed':sum(q['pass'] for q in r),'strictQueriesReturned':sum(q['returned'] for q in st),'strictReferenceEnclosures':sum(q.get('encloses',False) for q in st),'strictAbsTolCertificates':sum(q.get('absTolCertificate',False) for q in st),'strictNonzeroAmplitudes':sum(q.get('relativeError') is not None for q in st),'strictRelTolCertificates':sum(q.get('relTolCertificate',False) and q.get('relativeError') is not None for q in st),'checkpoints':sum(c['checkpoints'] for c in cs),'expectedCheckpoints':sum(c['expectedCheckpoints'] for c in cs),'checkpointNormEnclosures':sum(c.get('checkpointNormEnclosures',0) for c in cs),'maxAbsoluteError':max((q.get('absoluteError',0) for q in r),default=0),'maxRelativeError':max([q.get('relativeError') or 0 for q in r]+[0]),'maxRssMiB':max([c.get('peakRssMiB') or 0 for c in cs]+[0]),'elapsedSeconds':manifest['elapsedSeconds'] if manifest else None,'manifestSHA256':sha(mf) if manifest else None};stats[suite]=s
 if suite=='opus':s['referenceCommitmentMatches']=digest(load(E/'references/opus/reveal-private.json'))==commit['referenceCommitmentSHA256']
print(json.dumps(stats,indent=2));(F/'rerun-summary.json').write_text(json.dumps(stats,indent=2)+'\n');(F/'rerun-queries.json').write_text(json.dumps(rows,indent=2)+'\n');(F/'rerun-cases.json').write_text(json.dumps(cases,indent=2)+'\n')
# Last observed printed attempt is not the finalized 105 grade: some later stages never ran.
h=load(E/'historical-v15/diamond-results.json');last={};attempts=collections.Counter()
for line in (F/'diamond.log').read_text().splitlines():
 m=re.match(r'^(\d+) (PASS|PARTIAL|FAIL|BLOCKED|NOT_RUN) (.*)',line)
 if m: i=int(m[1]);last[i]=(m[2],m[3]);attempts[i]+=1
with (F/'diamond-observed.csv').open('w',newline='') as o:
 w=csv.writer(o);w.writerow(['id','requirement','historical_v15_final','v16_last_printed_attempt_not_final','attempts_printed','last_printed_evidence','historical_evidence']);
 for i in h['results']: w.writerow([i['id'],i['title'],i['status'],last.get(i['id'],('NO_PRINTED_ATTEMPT',''))[0],attempts[i['id']],last.get(i['id'],('',''))[1],i['evidence']])
print('Diamond observed only:',len(last),dict(collections.Counter(v[0] for v in last.values())))
