# DSIQ v0.16 scientific validation — private evidence bundle
19 November 2026. **Not certified or independently peer-reviewed.**

Source: GitHub commit `3fee3945c3ff98e9417b19fcb511510563ecabd0`; scientific fingerprint `ec11c1a0114b71a47e9ae404ac5ce7c8af283be18a00348512b4df5c2277877a` (121 files; re-hashed after execution). Original candidate and private validation ZIPs supplied by the owner are prerequisites. Keep the original reference material private. This bundle contains rerun outputs, new test input/expected/output values, charts, original source manifest and historical v0.15 results; it does not redistribute the original blind challenge/reveal files. All 60 known circuits were rerun; 566/566 numerical queries passed, with 220/222 original strict enclosures and 796 measured Astra checkpoints (Opus 6453 not measured). Same known workloads, not fresh blind challenges. Original native regression and new independently coded oracle comparisons passed (992 and 120 respectively). Diamond run timed out at 100 s; the last finalized score is v0.15. The CSV is the last printed attempt per ID, not a final grade.

## Evidence files
- `archive-audit.json` and `rescore-queries.json`: original supplied evidence re-hash/re-score.
- `rerun-summary.json`, `rerun-cases.json`, `rerun-queries.json`: rerun scoring, with raw records in `medium-rerun/`, `high-rerun/`, `opus-rerun/`.
- `fresh-inputs.json`, `fresh-queries.json`, `fresh-summary.json`: new deterministic seed 202611190753; mpmath oracle at 85 digits, with structured 50/100-qubit products of independently evolved 2-qubit states. Not a fresh blind test.
- `native-test.json`, `native-test.log`, `worker.*`: original native/worker tests with fresh execution logs.
- `diamond.log`, `diamond.stderr`, `diamond.exit`, `diamond-observed.csv`: incomplete 100 s rerun, no new final grade. `historical-v15-diamond-results.json` is the previous final score.
- `validate.py`: exact executed archive audit and fresh oracle script (the only hard-coded path is the original ZIP hash check; see below).
- `score_reruns.py`: separate scorer; run after workers exit.
- `figures/`: charts sourced from machine-readable results, not simulated screenshots. `make_report.py` is the report build script (original directory layout expected; the PDF is supplied separately).
- `SHA256SUMS`: hashes for evidence files in this ZIP. Verify with `sha256sum -c SHA256SUMS` from the extracted folder.

## Reproduction on Linux
Unzip the original candidate (SRC points to the inner DSIQ-v0.16-candidate directory), original private validation archive (EVID points to its extracted root), and this evidence bundle (BUNDLE). Use a **new** output directory for the rerun. Install exact dependencies from `requirements-query-native.txt` in a Python environment, GCC with libquadmath, and Node. Run from the frozen source root:

```sh
export SRC=/path/to/DSIQ-v0.16-candidate
export EVID=/path/to/original-private-evidence
export BUNDLE=/path/to/extracted-new-evidence
export OUT=/path/to/new-output
mkdir -p "$OUT"
cd "$SRC"
sh scripts/build-query-native.sh "$OUT/native"
export DSIQ_REGION_DP_LIBRARY="$OUT/native/region_dp.so"
export DSIQ_QUAD_LIBRARY="$OUT/native/quad_center.so"
export OPENBLAS_NUM_THREADS=1
python -B tests/v16-native.test.py > "$OUT/native-test.json"
node tests/worker.test.mjs > "$OUT/worker.log"
# Match the observed bounded attempt; remove timeout only for an appropriately provisioned full gate run.
timeout 100 node tests/diamond.test.mjs "$OUT/diamond-results.json" > "$OUT/diamond.log" 2> "$OUT/diamond.stderr"
# Exit 124 is a timeout, not a pass. Exit 1 reports a completed nonqualifying gate.
python -B tests/astra-regression.py execute "$EVID/inputs/medium/challenge.json" "$EVID/inputs/medium/commitment.json" "$OUT/medium-rerun" --timeout 120 --limit-mib 2048 --workers 2
python -B tests/astra-regression.py execute "$EVID/inputs/high/challenge.json" "$EVID/inputs/high/commitment.json" "$OUT/high-rerun" --timeout 120 --limit-mib 2048 --workers 2
python -B tests/v14-query-campaign.py "$EVID/inputs/opus/challenge.json" "$OUT/opus-rerun" --timeout 120 --workers 2
python "$BUNDLE/score_reruns.py" "$EVID" "$OUT"
```

For `validate.py`, preserve the original script and replace its literal path `/mnt/data/DSIQ-v0.16-private-engineering-candidate(1).zip` with the actual path to the original unmodified ZIP in a *copy* before running `python -B /path/to/copy.py "$SRC" "$EVID" "$OUT"`. No engine source is modified. This is a same-evaluation reproduction, not independent team certification. Timing/planner choices may differ with hardware.
